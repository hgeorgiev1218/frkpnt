var express = require('express');
var router = express.Router();
const fs = require('fs');

/* GET home page. */
router.get('/', function(req, res, next) {
  var categories = require('../db/categories.json');
  var products = require('../db/products.json');

  const filterCategory = req.query.category
  const filteredProducts = filterCategory ? products.filter(product => product.categotyId === filterCategory) : products;
  
  res.render('index', { title: 'Express', categories, products: filteredProducts});
});

module.exports = router;
